package com.codewitharuu.countrypicker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;

public class MainActivity extends AppCompatActivity {
    CountryCodePicker cpp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cpp = findViewById(R.id.ccp);
        cpp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener(){
            @Override
            public void onCountrySelected(Country selectedCountry){
                Toast.makeText(getApplicationContext(), "Updated"+selectedCountry.getName(), Toast.LENGTH_SHORT).show();

            }
        });
    }


}